.. _core_api_interrupt_exception:

Interrupts and Exceptions
=========================

Interrupt and Exception API
---------------------------

.. doxygengroup:: NMSIS_Core_IntExc
   :project: nmsis_core
   :outline:
   :content-only:

.. doxygengroup:: NMSIS_Core_IntExc
   :project: nmsis_core
