.. _core_api_csr_encoding:

Core CSR Encoding
=================


Core CSR Register Definitions
-----------------------------

.. doxygengroup:: NMSIS_Core_CSR_Registers
   :project: nmsis_core

Other Core Related Macros
-------------------------

.. doxygengroup:: NMSIS_Core_CSR_Encoding
   :project: nmsis_core

