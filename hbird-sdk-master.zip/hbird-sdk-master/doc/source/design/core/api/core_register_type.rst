.. _core_api_register_type:

Register Define and Type Definitions
====================================

.. doxygengroup:: NMSIS_Core_Registers
   :project: nmsis_core

Core
----

.. doxygengroup:: NMSIS_Core_Base_Registers
   :project: nmsis_core

PLIC
----

.. doxygengroup:: NMSIS_Core_PLIC_Registers
   :project: nmsis_core

SysTimer
--------

.. doxygengroup:: NMSIS_Core_SysTimer_Registers
   :project: nmsis_core

