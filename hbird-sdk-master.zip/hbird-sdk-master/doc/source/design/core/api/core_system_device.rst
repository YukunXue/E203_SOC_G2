.. _core_api_system_device:

System Device Configuration
===========================

.. doxygengroup:: NMSIS_Core_SystemConfig
   :project: nmsis_core

.. _core_api_intexc_nmi_handling:

Interrupt Exception NMI Handling
--------------------------------

.. doxygengroup:: NMSIS_Core_IntExcNMI_Handling
   :project: nmsis_core
