.. _core_api_compiler_control:

Compiler Control
================

.. doxygengroup:: NMSIS_Core_CompilerControl
   :project: nmsis_core

