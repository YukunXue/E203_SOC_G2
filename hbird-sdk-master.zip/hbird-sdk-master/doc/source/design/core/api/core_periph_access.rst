.. _core_api_periph_access:

Peripheral Access
=================

.. doxygengroup:: NMSIS_Core_PeriphAccess
   :project: nmsis_core
   :outline:
   :content-only:

.. doxygengroup:: NMSIS_Core_PeriphAccess
   :project: nmsis_core

