.. _design:

Design and Architecture
=======================

.. toctree::
   :maxdepth: 3

   overview.rst
   hbird.rst
   soc/index.rst
   board/index.rst
   peripheral.rst
   rtos.rst
   app.rst
